package mikespackage;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;

	import javax.naming.Context;
	import javax.naming.InitialContext;
	import javax.naming.NamingException;
	import javax.sql.DataSource;

	public class PersonUtil {

		private static PersonUtil instance;
		private DataSource dataSource;
		private String jndiName = "java:comp/env/jdbc/person_db";

		public static PersonUtil getInstance() throws Exception {
			if (instance == null) {
				instance = new PersonUtil();
			}

			return instance;
		}

		private PersonUtil() throws Exception {
			dataSource = getDataSource();
		}

		private DataSource getDataSource() throws NamingException {
			Context context = new InitialContext();

			DataSource theDataSource = (DataSource) context.lookup(jndiName);

			return theDataSource;
		}

		public List<Person> getPersons() throws Exception {

			List<Person> persons = new ArrayList<>();

			Connection myConn = null;
			Statement myStmt = null;
			ResultSet myRs = null;

			try {
				myConn = getConnection();

				String sql = "select * from person_table order by family";

				myStmt = myConn.createStatement();

				myRs = myStmt.executeQuery(sql);

				
				while (myRs.next()) {

				
					int id = myRs.getInt("id");
					String name = myRs.getString("name");
					String family = myRs.getString("family");
					String phone = myRs.getString("phone");
					String address = myRs.getString("address");
					String email = myRs.getString("email");
					String username = myRs.getString("username");
					String password = myRs.getString("password");
					

					
					Person tempPerson = new Person(id, name, family, phone, address,email,username,password);

					
					persons.add(tempPerson);
				}

				return persons;
			} finally {
				close(myConn, myStmt, myRs);
			}
		}

		public void addPerson(Person thePerson) throws Exception {

			System.out.println(thePerson);
			
			Connection myConn = null;
			PreparedStatement myStmt = null;

			try {
				myConn = getConnection();

				String sql = "insert into person_table (id,name, family, phone, address, email, username, password) values (?, ?, ?,?,?,?,?,?)";

				myStmt = myConn.prepareStatement(sql);

				
				myStmt.setInt(1, thePerson.getId());
				myStmt.setString(2, thePerson.getName());
				myStmt.setString(3, thePerson.getFamily());
				myStmt.setString(4, thePerson.getPhone());
				myStmt.setString(5, thePerson.getAddress());
				myStmt.setString(6, thePerson.getEmail());
				myStmt.setString(7, thePerson.getUsername());
				myStmt.setString(8, thePerson.getPassword());
				
				myStmt.execute();
			} finally {
				close(myConn, myStmt);
			}

		}

		public Person getPerson(int personId) throws Exception {

			Connection myConn = null;
			PreparedStatement myStmt = null;
			ResultSet myRs = null;

			try {
				myConn = getConnection();

				String sql = "select * from person_table where id=?";

				myStmt = myConn.prepareStatement(sql);

				
				myStmt.setInt(1, personId);

				myRs = myStmt.executeQuery();

				Person thePerson = null;

				
				if (myRs.next()) {
					int id = myRs.getInt("id");
					String name = myRs.getString("name");
					String family = myRs.getString("family");
					String phone = myRs.getString("phone");
					String address = myRs.getString("address");
					String email = myRs.getString("email");
					String username = myRs.getString("username");
					String password = myRs.getString("password");
					
					thePerson = new Person(id, name, family, phone, address,email,username,password);
					
				} else {
					throw new Exception("Could not find person id: " + personId);
				}

				return thePerson;
			} finally {
				close(myConn, myStmt, myRs);
			}
		}

		public void updatePerson(Person thePerson) throws Exception {

			Connection myConn = null;
			PreparedStatement myStmt = null;

			try {
				myConn = getConnection();

				String sql = "update person_table " + " set name=?, family=?, phone=?, address=?, email=?, username=?, password=?" + " where id=?";

				myStmt = myConn.prepareStatement(sql);

				
				myStmt.setString(1, thePerson.getName());
				myStmt.setString(2, thePerson.getFamily());
				myStmt.setString(3, thePerson.getPhone());
				myStmt.setString(4, thePerson.getAddress());
				myStmt.setString(5, thePerson.getEmail());
				myStmt.setString(6, thePerson.getUsername());
				myStmt.setString(7, thePerson.getPassword());

				myStmt.execute();
			} finally {
				close(myConn, myStmt);
			}

		}

		public void deletePerson(int personId) throws Exception {

			Connection myConn = null;
			PreparedStatement myStmt = null;

			try {
				myConn = getConnection();

				String sql = "delete from person_table where id=?";

				myStmt = myConn.prepareStatement(sql);

				
				myStmt.setInt(1, personId);

				myStmt.execute();
			} finally {
				close(myConn, myStmt);
			}
		}

		private Connection getConnection() throws Exception {

			Connection theConn = dataSource.getConnection();

			return theConn;
		}

		private void close(Connection theConn, Statement theStmt) {
			close(theConn, theStmt, null);
		}

		private void close(Connection theConn, Statement theStmt, ResultSet theRs) {

			try {
				if (theRs != null) {
					theRs.close();
				}

				if (theStmt != null) {
					theStmt.close();
				}

				if (theConn != null) {
					theConn.close();
				}

			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}

		// Search method ----------------------------------------------------------------
		public List<Person> searchPersons(String theSearchName) throws Exception {

			// 1- Result list
			List<Person> persons = new ArrayList<>();

			// 2- Clean attributes
			Connection myConn = null;
			PreparedStatement myStmt = null;
			ResultSet myRs = null;
			int personId;

			try {

				
				myConn = dataSource.getConnection();

				
				if (theSearchName != null && theSearchName.trim().length() > 0) {

				
					String sql = "select * from person_table where lower(name) like ? or lower(family) like ?";

					
					myStmt = myConn.prepareStatement(sql);

					
					String theSearchNameLike = "%" + theSearchName.toLowerCase() + "%";
					myStmt.setString(1, theSearchNameLike);
					myStmt.setString(2, theSearchNameLike);

				} else {
					
					String sql = "select * from person_table order by family";

					
					myStmt = myConn.prepareStatement(sql);
				}

			
				myRs = myStmt.executeQuery();

				
				while (myRs.next()) {

					int id = myRs.getInt("id");
					String name = myRs.getString("name");
					String family = myRs.getString("family");
					String phone = myRs.getString("phone");
					String address = myRs.getString("address");
					String email = myRs.getString("email");
					String username = myRs.getString("username");
					String password = myRs.getString("password");
					
					Person tempPerson = new Person(id, name, family, phone, address,email,username,password);
					

					
					persons.add(tempPerson);
				}

				return persons;
			} finally {

				// 15- Clean up JDBC objects
				close(myConn, myStmt, myRs);
			}
		}
		// ------------------------------------------------------------------------------

	}
	
	
	

