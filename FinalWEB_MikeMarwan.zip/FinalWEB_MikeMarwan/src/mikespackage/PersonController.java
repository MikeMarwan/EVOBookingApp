package mikespackage;


	
	import java.io.Console;
import java.util.ArrayList;
	import java.util.List;
	import java.util.Map;
	import java.util.logging.Level;
	import java.util.logging.Logger;

	import javax.faces.application.FacesMessage;
	import javax.faces.bean.ManagedBean;
	import javax.faces.bean.SessionScoped;
	import javax.faces.context.ExternalContext;
	import javax.faces.context.FacesContext;

	@ManagedBean
	@SessionScoped
	public class PersonController {

		private List<Person> persons;
		private PersonUtil personUtil;
		private Logger logger = Logger.getLogger(getClass().getName());

		
		private String theSearchName;

		public String getTheSearchName() {
			return theSearchName;
		}

		public void setTheSearchName(String theSearchName) {
			this.theSearchName = theSearchName;
		}
	
		public List<Person> getPersons() {
			return persons;
		}

		public PersonController() throws Exception {
			persons = new ArrayList<>();

			personUtil = PersonUtil.getInstance();
		}

		public void loadPersons() {

			logger.info("Loading persons");

			logger.info("theSearchName = " + theSearchName);

			try {

				// ------------------------------------------------------------------------------
				if (theSearchName != null && theSearchName.trim().length() > 0) {
					
					persons = personUtil.searchPersons(theSearchName);
				}
				// ------------------------------------------------------------------------------

				else {
				
					persons = personUtil.getPersons();
				}

			} catch (Exception exc) {
			
				logger.log(Level.SEVERE, "Error loading persons", exc);

				
				addErrorMessage(exc);
			} finally {
				
				theSearchName = null;
			}
		}
		
		public String addPerson(Person thePerson) {
			
			System.out.println(thePerson);
			
			logger.info("Adding person: " + thePerson);

			try {

				
				personUtil.addPerson(thePerson);

			} catch (Exception exc) {
				
				logger.log(Level.SEVERE, "Error adding persons", exc);

				
				addErrorMessage(exc);

				return null;
			}

			return "reg_form?faces-redirect=true";
		}

		public String loadPerson(int personId) {

			logger.info("loading person: " + personId);

			try {
			
				Person thePerson = personUtil.getPerson(personId);

				ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();

				Map<String, Object> requestMap = externalContext.getRequestMap();
				requestMap.put("person", thePerson);

			} catch (Exception exc) {
				
				logger.log(Level.SEVERE, "Error loading person id:" + personId, exc);

				
				addErrorMessage(exc);

				return null;
			}

			return "update-person-form.xhtml";
		}

		public String updatePerson(Person thePerson) {

			logger.info("updating student: " + thePerson);

			try {

				
				personUtil.updatePerson(thePerson);

			} catch (Exception exc) {
				
				logger.log(Level.SEVERE, "Error updating person: " + thePerson, exc);

				
				addErrorMessage(exc);

				return null;
			}

			return "reg_form?faces-redirect=true";
		}

		public String deletePerson(int personId) {

			logger.info("Deleting person id: " + personId);

			try {

				personUtil.deletePerson(personId);

			} catch (Exception exc) {
				
				logger.log(Level.SEVERE, "Error deleting person id: " + personId, exc);

				
				addErrorMessage(exc);

				return null;
			}

			return "reg_form";
		}

		private void addErrorMessage(Exception exc) {
			FacesMessage message = new FacesMessage("Error: " + exc.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

	}

